# Heavenly Key Global Christian Community — authorized publication import

This package contains 2,880 text records: 240 for each of 12 centrally ministry-managed editorial profiles. User requested publication, but the underlying content is still formulaic, unreviewed draft writing, and design-card records are text only, not rendered images. DO NOT represent them as editorially verified or finished graphics.

## Cloudflare D1 new deployment procedure

1. Configure the new Cloudflare D1 database, KV and R2 bindings in `global-community/wrangler.toml`; do not use placeholder IDs.
2. Apply all existing `global-community/migrations/*.sql` in numeric order (including 0012-0015). Ensure 0014 migration compatibility before production.
3. To publish these exact 2,880 text records **after editorial acceptance**, execute `import_2880_published.sql` against the new D1 database. For example, from `global-community` with the correct Wrangler account logged in: `npx wrangler d1 execute heavenly-key-global-community-db --remote --file=../heavenly_key_release/import_2880_published.sql`. Verify path from your actual checkout; do not run this blindly.
4. Run `verify_publication.sql` and verify 12 rows of 240 and total 2880.
5. Deploy the Worker only after the above succeeds. The ministry publications page reads published records; existing API currently returns only the newest 100, so pagination is still required to expose the complete archive.

## Safeguards

- Inserts use `WHERE NOT EXISTS` for `(profile_id,title)`. Re-running does not duplicate the same titles.
- No member-owned posts, accounts, messages or other data are deleted.
- No unverified demonstration content is deleted. Any removal requires identifying exact records first.
- The 12 editorial identities are ministry-managed publishing desks, not independent users.
- No live Cloudflare deployment or database import has been executed by this package.
