SELECT profile_id,COUNT(*) AS published_count FROM ministry_editorial_posts WHERE status='published' GROUP BY profile_id ORDER BY profile_id;
SELECT COUNT(*) AS total_published FROM ministry_editorial_posts WHERE status='published';
